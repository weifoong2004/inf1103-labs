from product import Product
from supplier import Supplier


class DigitalProduct(Product):
    def __init__(self, product_id: str, name: str, price: float,
                 stock: int, download_size: float, supplier: Supplier) -> None:
        super().__init__(product_id, name, price, stock, supplier)
        self._download_size: float = download_size

    def get_download_size(self) -> float:
        return self._download_size

    def display_information(self) -> None:
        super().display_information()
        print(f"Download Size: {self._download_size} MB")

    def get_fulfilment_info(self) -> str:
        return f"{self.get_name()} is delivered digitally via download."

    def to_dict(self) -> dict[str, str | float | int | dict[str, str]]:
        data = super().to_dict()
        data["type"] = "digital"
        data["download_size"] = self._download_size
        return data
